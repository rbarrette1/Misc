<htm>
<head>
  <title>EOC</title>
</head>
<body>
  <h2>EOC</h2>
  <hr />

<?php

  include('./php/dbvars.php');
  include('./php/dbconnect.php');

  //$dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME) or die("Could not display page!"); 
  // Retrieve the score data from MySQL
  $query = "SELECT * FROM users WHERE 1 ";
  $data = mysqli_query($dbc, $query);

  // Loop through the array of score data, formatting it as HTML 
  echo '<table>';
  while ($row = mysqli_fetch_array($data)) { 
    // Display the score data
	
    echo '<tr ><td><strong>' . $row['user_name'] . '</strong></td>';
    echo '<td>' . $row['user_date'] . '</td>';
    echo '<td>' . $row['user_id'] . '</td>';
	echo '<tr>';
	}
  echo '</table>';
  
  $query = "SELECT images.gal_id, images.image_id, images.image_name, images.image_path, gallery.gal_description FROM `gallery`, `images` WHERE images.gal_id = 2 AND gallery.gal_id = 2 ";
  $data = mysqli_query($dbc, $query);
  
  echo '<table>';
  
  while ($row = mysqli_fetch_array($data)) { 
    // Display the score data
	
    echo '<tr ><td><strong>' . '<p>Image id</p>'.$row['image_id'] . '</strong></td>';
    echo '<td>' . '<p>Name:</p>'.$row['image_name'] . '</td>';
	echo '<td>' . '<img src="'.$row['image_path'] .' " width="20%"  >'. '</td>';
	echo '<tr>';
	}
  echo '</table>';

?>

</body> 
</html>
