<?php
//Define database connection constants
define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASSWORD', '');//'COSCUser2017');
define('DB_NAME','eoc'); //'ethek');

?>
