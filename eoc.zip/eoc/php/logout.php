<?php

	
				//Internet Tools Project
				//Version 1.0
				//logout.php
				//Authors:  Rachelle Barrette
				//				Thomas Malley
			
				//Date: 		2017-02-02
				//Working: YES
			
						                               // -->
	session_start();
	//$seconds = -10+ time();
	//setcookie(loggedin, date("F jS - g:i a"), $seconds);
	$seconds = time() - (60*60*24*30);
	setcookie('user_id',$row['user_id'], $seconds); //expires in 30 days
	setcookie('username',$row['username'], $seconds); //expires in 30 days
	
	session_destroy();
	header("location:../login.php");

?>
