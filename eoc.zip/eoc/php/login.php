<?php

require_once('connectvars.php');	


//connect to the database	
$dbhandle =  mysql_connect(DB_HOST, DB_USER, DB_PASSWORD) or die("Could not load page");
	
$selected = mysql_select_db(DB_NAME, $dbhandle);

		
//Grab user entered log in data
$myusername= $_POST['username'];
$mypassword= $_POST['password'];

//Prevent sql injection
$myusername = stripslashes($myusername);
$mypassword = stripslashes($mypassword);


$query = "select * from ethek_admins where username='$myusername' and  password=sha('$mypassword')";
$result = mysql_query($query);

$count = mysql_num_rows($result);

mysql_close();
	
if($count == 1){
$seconds = 120 + time();
setcookie(loggedin, date("F jS - g:i a"), $seconds);
header("location:welcome.php"); 
}else{
	//The username/password are incorrect
	echo 'Sorry, you must enter a valid username and password to log in.';
}	
	
	
?>
