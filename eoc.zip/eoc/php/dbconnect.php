<?php
  require_once('dbvars.php');

  // Connect to the database 
  $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME) or die("Could not display page!"); 

  // Retrieve the score data from MySQL
  //$query = "SELECT * FROM users";
  //$data = mysqli_query($dbc, $query);
	
  //mysqli_close($dbc);
?>