CREATE TABLE users (
user_id     INT(8) NOT NULL AUTO_INCREMENT,
user_name   VARCHAR(30) NOT NULL,
user_pass   VARCHAR(255) NOT NULL,
user_date   DATETIME NOT NULL,
PRIMARY KEY (user_id)
);

//gallery 
//id uniq value for each row
//gal name ex deck1
//gal description - short description of the gallery(This deck was built...)
//cat_id  either 0 or 1. 0 for designs and 1 for projects


CREATE TABLE gallery (
gal_id          INT(8) NOT NULL AUTO_INCREMENT,
gal_name        VARCHAR(15) NOT NULL, 
gal_description     VARCHAR(255) NOT NULL,
cat_id			INT(2) NOT NULL,   design or project
PRIMARY KEY (gal_id)
);

CREATE TABLE projects (
proj_id          INT(8) NOT NULL AUTO_INCREMENT,
proj_name        VARCHAR(15) NOT NULL, 
proj_description     VARCHAR(255) NOT NULL,
PRIMARY KEY (gal_id)
);

//pictures (second table because one gallery will have multiple pictures)
//image_id uniq value for each image_id
//image name
//gal_id -does it belon to designs(0) or projects(1)
//path to the image ex ./images/projects/image1.jpg


CREATE TABLE images(
image_id		INT(8) NOT NULL AUTO_INCREMENT,
image_name VARCHAR(30),
gal_id		INT(8) NOT NULL,
image_path VARCHAR(255),
PRIMARY KEY (image_id)
);

INSERT INTO images


INSERT INTO `gallery`(`gal_id`, `gal_name`, `gal_description`, `cat_id`) VALUES (0,"designs","eoc custom desings",0);
INSERT INTO `images`(`image_id`, `image_name`, `gal_id`, `image_path`) VALUES (2,"drawing1",0,"./images/desings/drawing1.jpg.");


ALTER TABLE `images` ADD FOREIGN KEY (`gal_id`) REFERENCES `eoc`.`gallery`(`gal_id`) ON DELETE RESTRICT ON UPDATE RESTRICT;



SELECT gal_id, image_name, image_path, gal_description FROM gallery, images WHERE images.gal_id =2
SELECT images.gal_id, images.image_name, images.image_path, gallery.gal_description FROM gallery, images WHERE images.gal_id = 2 







SELECT images.gal_id, images.image_name, images.image_path, gallery.gal_description FROM `gallery`, `images` WHERE images.gal_id = 2 AND gallery.gal_id = 2 

^^^^^THAT ONE WORKS^^^^^
displays all pictures that have gallery id of 2(same for other gallery


select image_name, image_path from images
returns all pictures in the database